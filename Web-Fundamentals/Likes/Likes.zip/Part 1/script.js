function add1() {
    document.querySelector(".likenumber").innerText++;
}