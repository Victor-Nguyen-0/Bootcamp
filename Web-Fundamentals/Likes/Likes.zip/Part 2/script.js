var likes = [9,12,9];

function add0() {
    likes[0]++;
    document.getElementById("likenumber0").innerText=likes[0];
}

function add1() {
    likes[1]++;
    document.getElementById("likenumber1").innerText=likes[1];
}

function add2() {
    likes[2]++;
    document.getElementById("likenumber2").innerText=likes[2];
}