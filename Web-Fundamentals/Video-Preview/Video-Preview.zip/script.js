function hoverplay() {
    document.getElementById("myvideo").play();
}

function unhoverpause() {
    document.getElementById("myvideo").pause();
}