function logout() {
    document.getElementById('login').innerHTML="Log Out";
}

function hidebutton(element) {
    element.remove();
}